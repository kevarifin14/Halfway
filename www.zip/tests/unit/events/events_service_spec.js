describe('Events Service', function() {
});
